<!-- Créer un compte sur https://fr.000webhost.com/ ou https://infinityfree.net/ ou l’hébergeur de votre choix et uplaoder 
vos codes-sources de l’évaluation sur ce serveur.

Vous devrez rendre l’adresse url de votre site web afin que le correcteur puisse évaluer votre travail.

Par exemple : http://www.julien-cottet.fr/evaluation-php/

Ne mettez pas de fichier index afin que le correcteur puisse avoir accès à votre listing de fichier.

En fin d’évaluation, pensez à uplaoder l’archive .rar de votre projet afin que le correcteur puisse observer votre
code-source directement sur le serveur.-->